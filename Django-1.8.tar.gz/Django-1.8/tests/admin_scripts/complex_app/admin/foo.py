from django.contrib import admin

from ..models.foo import Foo

admin.site.register(Foo)
